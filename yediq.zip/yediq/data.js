/* data.js — dijana oleh Mann Store Admin Panel
   Tarikh: 10/11/2026 00:30
   JANGAN edit fail ini secara manual. Guna admin.html. */
window.STORE_CONFIG = {
  "version": 1,
  "store": {
    "name": "Mann Store Top-Up",
    "headerLogo": "mannheader-logo.png",
    "adminWA": "60109248949",
    "taglines": [
      "100% Trusted",
      "Amanah",
      "24 Hours Service"
    ],
    "footerTagline": "Keselesaan anda ialah Keutamaan kami.",
    "footerNote": "All purchases cannot be refund except it's our mistake.",
    "posters": [
      "mannposter-poster.png",
      "mannposter2-poster.png"
    ],
    "orderPrefix": "#MS",
    "timerSeconds": 120,
    "currency": "RM"
  },
  "qr": {
    "duitnow": "duitnow-qr.png",
    "shopeepay": "shopeepay-qr.png"
  },
  "games": [
    {
      "id": "robux",
      "name": "Topup Robux",
      "shortName": "Robux",
      "formType": "username",
      "items": [
        {
          "name": "100 Robux",
          "price": 3.57,
          "icon": "🔴"
        },
        {
          "name": "200 Robux",
          "price": 7.3,
          "icon": "🔴"
        },
        {
          "name": "300 Robux",
          "price": 10.85,
          "icon": "🔴"
        },
        {
          "name": "400 Robux",
          "price": 14.45,
          "icon": "🔴"
        },
        {
          "name": "495 + 5 Robux",
          "price": 17.1,
          "icon": "🔴"
        },
        {
          "name": "600 Robux",
          "price": 21.4,
          "icon": "🔴"
        },
        {
          "name": "700 Robux",
          "price": 24.6,
          "icon": "🔴"
        },
        {
          "name": "800 Robux",
          "price": 26.4,
          "icon": "🔴"
        },
        {
          "name": "1000 Robux",
          "price": 38.2,
          "icon": "🔴"
        },
        {
          "name": "1500 Robux",
          "price": 52.39,
          "icon": "🔴"
        },
        {
          "name": "2000 Robux",
          "price": 69.9,
          "icon": "🔴"
        },
        {
          "name": "5000 Robux",
          "price": 173.9,
          "icon": "🔴"
        }
      ]
    },
    {
      "id": "ff",
      "name": "Topup Free Fire",
      "shortName": "Free Fire",
      "formType": "id",
      "items": [
        {
          "name": "Weekly Lite",
          "price": 1.53,
          "icon": "🎟️"
        },
        {
          "name": "Weekly",
          "price": 7.15,
          "icon": "🎟️"
        },
        {
          "name": "Monthly",
          "price": 35.49,
          "icon": "🎟️"
        },
        {
          "name": "25 Diamonds",
          "price": 1.15,
          "icon": "💎"
        },
        {
          "name": "50 Diamonds",
          "price": 2.23,
          "icon": "💎"
        },
        {
          "name": "100 Diamonds",
          "price": 4.19,
          "icon": "💎"
        },
        {
          "name": "200 Diamonds",
          "price": 8.34,
          "icon": "💎"
        },
        {
          "name": "300 Diamonds",
          "price": 12.46,
          "icon": "💎"
        },
        {
          "name": "310 Diamonds",
          "price": 12.59,
          "icon": "💎"
        },
        {
          "name": "520 Diamonds",
          "price": 20.99,
          "icon": "💎"
        },
        {
          "name": "830 Diamonds",
          "price": 33.59,
          "icon": "💎"
        },
        {
          "name": "930 Diamonds",
          "price": 37.64,
          "icon": "💎"
        },
        {
          "name": "1060 Diamonds",
          "price": 41.21,
          "icon": "💎"
        },
        {
          "name": "1580 Diamonds",
          "price": 62.09,
          "icon": "💎"
        },
        {
          "name": "2180 Diamonds",
          "price": 83.14,
          "icon": "💎"
        },
        {
          "name": "3240 Diamonds",
          "price": 124.3,
          "icon": "💎"
        },
        {
          "name": "5600 Diamonds",
          "price": 205.71,
          "icon": "💎"
        },
        {
          "name": "11500 Diamonds",
          "price": 423.62,
          "icon": "💎"
        }
      ]
    },
    {
      "id": "ffmax",
      "name": "Topup FF MAX",
      "shortName": "Free Fire MAX",
      "formType": "id",
      "items": [
        {
          "name": "Weekly Lite",
          "price": 1.55,
          "icon": "🎟️"
        },
        {
          "name": "Weekly",
          "price": 7.19,
          "icon": "🎟️"
        },
        {
          "name": "Monthly",
          "price": 35.56,
          "icon": "🎟️"
        },
        {
          "name": "25 Diamonds",
          "price": 1.14,
          "icon": "💎"
        },
        {
          "name": "50 Diamonds",
          "price": 2.23,
          "icon": "💎"
        },
        {
          "name": "100 Diamonds",
          "price": 4.19,
          "icon": "💎"
        },
        {
          "name": "310 Diamonds",
          "price": 12.62,
          "icon": "💎"
        },
        {
          "name": "520 Diamonds",
          "price": 20.99,
          "icon": "💎"
        },
        {
          "name": "1060 Diamonds",
          "price": 41.19,
          "icon": "💎"
        },
        {
          "name": "2180 Diamonds",
          "price": 83.13,
          "icon": "💎"
        }
      ]
    },
    {
      "id": "ml",
      "name": "Topup ML",
      "shortName": "ML",
      "formType": "id",
      "items": [
        {
          "name": "14 Dm",
          "price": 1.04,
          "icon": "💎"
        },
        {
          "name": "28 Dm",
          "price": 2.11,
          "icon": "💎"
        },
        {
          "name": "42 Dm",
          "price": 3.16,
          "icon": "💎"
        },
        {
          "name": "56 Dm",
          "price": 4.16,
          "icon": "💎"
        },
        {
          "name": "70 Dm",
          "price": 5.25,
          "icon": "💎"
        },
        {
          "name": "112 Dm",
          "price": 8.25,
          "icon": "💎"
        },
        {
          "name": "140 Dm",
          "price": 10.38,
          "icon": "💎"
        },
        {
          "name": "168 Dm",
          "price": 12.55,
          "icon": "💎"
        },
        {
          "name": "278 Dm",
          "price": 20.47,
          "icon": "💎"
        },
        {
          "name": "397 Dm",
          "price": 29.09,
          "icon": "💎"
        },
        {
          "name": "429 Dm",
          "price": 31.11,
          "icon": "💎"
        },
        {
          "name": "569 Dm",
          "price": 41.64,
          "icon": "💎"
        },
        {
          "name": "571 Dm",
          "price": 42.78,
          "icon": "💎"
        },
        {
          "name": "639 Dm",
          "price": 46.23,
          "icon": "💎"
        },
        {
          "name": "716 Dm",
          "price": 51.36,
          "icon": "💎"
        },
        {
          "name": "786 Dm",
          "price": 57.5,
          "icon": "💎"
        },
        {
          "name": "849 Dm",
          "price": 61.6,
          "icon": "💎"
        },
        {
          "name": "1220 Dm",
          "price": 89.9,
          "icon": "💎"
        }
      ]
    },
    {
      "id": "wdp",
      "name": "Topup WDP ML",
      "shortName": "WDP ML",
      "formType": "id",
      "items": [
        {
          "name": "Weekly Diamond Pass",
          "price": 8.52,
          "icon": "🎟️"
        },
        {
          "name": "Weekly Diamond Pass 2x",
          "price": 17.67,
          "icon": "🎟️"
        },
        {
          "name": "Weekly Diamond Pass 3x",
          "price": 25.83,
          "icon": "🎟️"
        },
        {
          "name": "Weekly Diamond Pass 4x",
          "price": 35.25,
          "icon": "🎟️"
        },
        {
          "name": "Weekly Diamond Pass 5x",
          "price": 42.84,
          "icon": "🎟️"
        }
      ]
    },
    {
      "id": "pubg",
      "name": "Topup PUBG Mobile",
      "shortName": "PUBG Mobile",
      "formType": "id",
      "items": [
        {
          "name": "60 UC",
          "price": 4.29,
          "icon": "🪙"
        },
        {
          "name": "300 + 25 UC",
          "price": 21.67,
          "icon": "🪙"
        },
        {
          "name": "600 + 60 UC",
          "price": 43.2,
          "icon": "🪙"
        },
        {
          "name": "1500 + 300 UC",
          "price": 107.89,
          "icon": "🪙"
        },
        {
          "name": "3000 + 850 UC",
          "price": 215.99,
          "icon": "🪙"
        },
        {
          "name": "6000 + 2100 UC",
          "price": 431.59,
          "icon": "🪙"
        }
      ]
    },
    {
      "id": "hok",
      "name": "Topup HOK",
      "shortName": "HOK",
      "formType": "id",
      "items": [
        {
          "name": "16 Tokens",
          "price": 0.9,
          "icon": "🪙"
        },
        {
          "name": "80 Tokens",
          "price": 4.06,
          "icon": "🪙"
        },
        {
          "name": "240 Tokens",
          "price": 12.05,
          "icon": "🪙"
        },
        {
          "name": "400 Tokens",
          "price": 20.04,
          "icon": "🪙"
        },
        {
          "name": "560 Tokens",
          "price": 28.03,
          "icon": "🪙"
        },
        {
          "name": "800 + 30 Tokens",
          "price": 40.02,
          "icon": "🪙"
        },
        {
          "name": "1200 + 45 Tokens",
          "price": 60,
          "icon": "🪙"
        },
        {
          "name": "2400 + 108 Tokens",
          "price": 119.94,
          "icon": "🪙"
        },
        {
          "name": "4000 + 180 Tokens",
          "price": 199.86,
          "icon": "🪙"
        },
        {
          "name": "8000 + 360 Tokens",
          "price": 399.65,
          "icon": "🪙"
        }
      ]
    },
    {
      "id": "fcm",
      "name": "Topup FCM",
      "shortName": "FC Mobile",
      "formType": "id",
      "items": [
        {
          "name": "40 FC Points",
          "price": 2.29,
          "icon": "⚽"
        },
        {
          "name": "39 Silver",
          "price": 2.29,
          "icon": "🪙"
        },
        {
          "name": "100 FC Points",
          "price": 5.5,
          "icon": "⚽"
        },
        {
          "name": "99 Silver",
          "price": 5.5,
          "icon": "🪙"
        },
        {
          "name": "520 FC Points",
          "price": 26.44,
          "icon": "⚽"
        },
        {
          "name": "499 Silver",
          "price": 26.44,
          "icon": "🪙"
        },
        {
          "name": "1070 FC Points",
          "price": 49.58,
          "icon": "⚽"
        },
        {
          "name": "999 Silver",
          "price": 49.58,
          "icon": "🪙"
        },
        {
          "name": "2200 FC Points",
          "price": 104.67,
          "icon": "⚽"
        },
        {
          "name": "1999 Silver",
          "price": 104.67,
          "icon": "🪙"
        },
        {
          "name": "5750 FC Points",
          "price": 264.44,
          "icon": "⚽"
        },
        {
          "name": "4999 Silver",
          "price": 264.44,
          "icon": "🪙"
        },
        {
          "name": "12000 FC Points",
          "price": 528.88,
          "icon": "⚽"
        },
        {
          "name": "9999 Silver",
          "price": 528.88,
          "icon": "🪙"
        }
      ]
    },
    {
      "id": "mcgg",
      "name": "Topup MCGG",
      "shortName": "MCGG",
      "formType": "id",
      "items": [
        {
          "name": "Weekly Pass",
          "price": 9.34,
          "icon": "🎟️"
        },
        {
          "name": "Weekly Pass x2",
          "price": 18.59,
          "icon": "🎟️"
        },
        {
          "name": "Weekly Pass x3",
          "price": 27.82,
          "icon": "🎟️"
        },
        {
          "name": "Weekly Pass x4",
          "price": 37.07,
          "icon": "🎟️"
        },
        {
          "name": "Weekly Pass x5",
          "price": 46.31,
          "icon": "🎟️"
        },
        {
          "name": "14 Diamonds ( 13 + 1 Bonus )",
          "price": 1.13,
          "icon": "💎"
        },
        {
          "name": "42 Diamonds ( 38 + 4 Bonus )",
          "price": 3.23,
          "icon": "💎"
        },
        {
          "name": "70 Diamonds ( 64 + 6 Bonus )",
          "price": 5.28,
          "icon": "💎"
        },
        {
          "name": "140 Diamonds ( 127 + 13 Bonus )",
          "price": 10.47,
          "icon": "💎"
        },
        {
          "name": "284 Diamonds ( 254 + 30 Bonus )",
          "price": 20.85,
          "icon": "💎"
        },
        {
          "name": "355 Diamonds ( 317 + 38 Bonus )",
          "price": 26.02,
          "icon": "💎"
        },
        {
          "name": "429 Diamonds ( 383 + 46 Bonus )",
          "price": 31.19,
          "icon": "💎"
        },
        {
          "name": "716 Diamonds ( 633 + 83 Bonus )",
          "price": 51.94,
          "icon": "💎"
        },
        {
          "name": "1084 Diamonds ( 940 + 144 Bonus )",
          "price": 77.86,
          "icon": "💎"
        },
        {
          "name": "1446 Diamonds ( 1252 + 194 Bonus )",
          "price": 103.78,
          "icon": "💎"
        },
        {
          "name": "2976 Diamonds ( 2501 + 475 Bonus )",
          "price": 207.42,
          "icon": "💎"
        },
        {
          "name": "7502 Diamonds ( 6252 + 1250 Bonus )",
          "price": 518.39,
          "icon": "💎"
        }
      ]
    }
  ],
  "payments": [
    {
      "name": "Touch n' Go eWallet",
      "logo": "tng",
      "qr": "duitnow"
    },
    {
      "name": "Maybank2u",
      "logo": "m2u",
      "qr": "duitnow"
    },
    {
      "name": "BSN",
      "logo": "bsn",
      "qr": "duitnow"
    },
    {
      "name": "GrabPay",
      "logo": "grab",
      "qr": "duitnow"
    },
    {
      "name": "Boost",
      "logo": "boost",
      "qr": "duitnow"
    },
    {
      "name": "ShopeePay",
      "logo": "shopee",
      "qr": "shopeepay"
    },
    {
      "name": "DuitNow QR",
      "logo": "duitnow",
      "qr": "duitnow"
    }
  ]
};
